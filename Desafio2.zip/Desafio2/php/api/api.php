<?php
require_once '../models/Documento.php';
header("Content-Type: application/json");

$doc = new Documento();
echo json_encode($doc->obtenerTodos());
?>
