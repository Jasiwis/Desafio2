<?php
// Redirige a la ubicación correcta si alguien accede a esta ruta equivocada
header("Location: views/dashboard.php");
exit();
