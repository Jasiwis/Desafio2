<?php
require_once '../models/Usuario.php';
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $password = $_POST['password'];

    if (!preg_match("/^[\w.-]+@[\w.-]+\.\w{2,4}$/", $email)) {
        die("Correo inválido");
    }

    if (!preg_match("/.{6,}/", $password)) {
        die("La contraseña debe tener al menos 6 caracteres");
    }

    $usuario = new Usuario();
    $usuario->registrar($email, $password);
    $_SESSION['usuario'] = $email;
    header("Location: ../views/dashboard.php");
}
?>
