<?php
class Documento {
    private $conn;

    public function __construct() {
        $this->conn = new mysqli("localhost", "root", "", "desafio2");
        if ($this->conn->connect_error) {
            die("Conexión fallida: " . $this->conn->connect_error);
        }
    }

    public function subir($usuario_id, $file) {
        $nombre = basename($file["name"]);
        $tipo = $file["type"];

        if (!preg_match("/^[\w\-. ]+\.(pdf|docx|txt)$/i", $nombre)) {
            die("Nombre de archivo inválido");
        }

        // Ruta relativa para guardar en la base de datos y mostrar en el navegador
        $ruta_relativa = "uploads/user_" . $usuario_id . "/" . $nombre;

        // Ruta absoluta para mover el archivo
        $ruta_absoluta = __DIR__ . "/../../" . $ruta_relativa;

        // Crear carpeta si no existe
        if (!is_dir(dirname($ruta_absoluta))) {
            mkdir(dirname($ruta_absoluta), 0777, true);
        }

        if (move_uploaded_file($file["tmp_name"], $ruta_absoluta)) {
            $stmt = $this->conn->prepare("INSERT INTO documentos (usuario_id, nombre, ruta, tipo) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isss", $usuario_id, $nombre, $ruta_relativa, $tipo);
            $stmt->execute();
        }
    }

    public function obtenerTodos() {
        $result = $this->conn->query("SELECT * FROM documentos");
        $documentos = [];
        while ($row = $result->fetch_assoc()) {
            $documentos[] = $row;
        }
        return $documentos;
    }
}
?>
